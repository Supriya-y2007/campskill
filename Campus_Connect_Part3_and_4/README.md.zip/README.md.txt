# Campus Connect — Roles 3 & 4 Deliverables

This folder contains all non-coding documentation, test suites, design tokens, and SQL seed data for Part 3 and Part 4 of the Campus Connect project.

## Included Files

### Part 3: QA Lead & Technical Writer
* `qa_test_cases.md` — Complete manual test suite for authentication, PDF generation, forms, and security.
* `system_flowchart.txt` — ASCII structural flowchart mapping application logic and navigation.

### Part 4: Product Designer & Content Manager
* `theme.css` — CSS custom properties defining project branding, palette, font settings, and global UI components.
* `seed_data.sql` — Database insertion script for placement drives, off-campus jobs, skills, and skill mappings.